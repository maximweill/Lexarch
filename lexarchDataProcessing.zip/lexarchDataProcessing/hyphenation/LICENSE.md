All files in this repository except files ending with `.md` are released into the public domain by it's author Grady Ward as seen [here](https://web.archive.org/web/20171130051121/http://icon.shef.ac.uk/Moby/):
```
The Moby lexicon project is complete and has
been place into the public domain. Use, sell,
rework, excerpt and use in any way on any platform.

Placing this material on internal or public servers is
also encouraged. The compiler is not aware of any
export restrictions so freely distribute world-wide.

You can verify the public domain status by contacting

Grady Ward
3449 Martha Ct.
Arcata, CA  95521-4884

daedal@myrealbox.com >>
```
All other files (files ending with `.md`) are licensed under [CC BY 4.0](http://creativecommons.org/licenses/by/4.0/).
